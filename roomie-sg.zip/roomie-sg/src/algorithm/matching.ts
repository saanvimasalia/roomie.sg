// ─────────────────────────────────────────────────────────────
// roomie.sg — Matching Algorithm
// This mirrors the SQL calc_match_score function exactly.
// Use this file for unit testing and local development.
// The real scoring runs in Postgres for performance.
// ─────────────────────────────────────────────────────────────

import type { UserProfile, MatchLabel, UserFilters } from '../types'

const GUEST_ORDER = ['never', 'rarely', 'sometimes', 'often'] as const
const CLEAN_ORDER = ['relaxed', 'average', 'tidy'] as const

// Maximum possible points
// 4 non-negotiables × 3 pts = 12
// 8 preferences × 1 pt = 8
// Total = 20
const MAX_POINTS = 20

// ── Hard filter ───────────────────────────────────────────────
// Returns true if profile B should be EXCLUDED from the For You feed
// based on user A's non-negotiables and active filters

export function isHardFiltered(
  me: UserProfile,
  other: UserProfile,
  filters: Partial<UserFilters> = {}
): boolean {
  // My own dietary requirement
  if (me.diet === 'halal' && other.diet !== 'halal' && other.diet !== 'none') return true
  if (me.diet === 'vegetarian' && other.diet !== 'vegetarian' && other.diet !== 'none') return true

  // My smoking preference
  if (!me.smoking && other.smoking) return true

  // Filter overrides
  if (filters.require_halal && other.diet !== 'halal' && other.diet !== 'none') return true
  if (filters.require_non_smoker && other.smoking) return true
  if (filters.require_ac && !other.needs_ac) return true
  if (filters.gender_preference && filters.gender_preference !== 'any') {
    // Gender filtering requires an additional gender field on profiles
    // Placeholder — implement when gender field is added
  }

  return false
}

// ── Score calculation ─────────────────────────────────────────

export function calcScore(a: UserProfile, b: UserProfile): number {
  let earned = 0

  // ── Non-negotiables (3 pts each) ─────────────────────────

  // Diet match
  if (a.diet === b.diet || a.diet === 'none' || b.diet === 'none') {
    earned += 3
  }

  // Smoking match
  if (a.smoking === b.smoking) {
    earned += 3
  }

  // AC match
  if (a.needs_ac === b.needs_ac) {
    earned += 3
  }

  // Hall match
  const hallA = a.hall_preference
  const hallB = b.hall_preference
  if (
    hallA && hallB &&
    (hallA === hallB || hallA === 'Any hall is fine' || hallB === 'Any hall is fine')
  ) {
    earned += 3
  }

  // ── Preferences (1 pt each) ───────────────────────────────

  // Sleep time (within 2 hours, accounting for midnight wrap)
  if (a.sleep_time != null && b.sleep_time != null) {
    const diff = Math.abs(a.sleep_time - b.sleep_time)
    if (diff <= 2 || diff >= 22) earned += 1
  }

  // Wake time (within 2 hours)
  if (a.wake_time != null && b.wake_time != null) {
    if (Math.abs(a.wake_time - b.wake_time) <= 2) earned += 1
  }

  // Social style
  if (a.social_style && b.social_style) {
    if (
      a.social_style === b.social_style ||
      a.social_style === 'ambivert' ||
      b.social_style === 'ambivert'
    ) {
      earned += 1
    }
  }

  // Guest frequency (within 1 level)
  if (a.guest_frequency && b.guest_frequency) {
    const aIdx = GUEST_ORDER.indexOf(a.guest_frequency as typeof GUEST_ORDER[number])
    const bIdx = GUEST_ORDER.indexOf(b.guest_frequency as typeof GUEST_ORDER[number])
    if (aIdx !== -1 && bIdx !== -1 && Math.abs(aIdx - bIdx) <= 1) earned += 1
  }

  // Study location
  if (a.study_location && a.study_location === b.study_location) earned += 1

  // Cleanliness (within 1 level)
  if (a.cleanliness && b.cleanliness) {
    const aIdx = CLEAN_ORDER.indexOf(a.cleanliness as typeof CLEAN_ORDER[number])
    const bIdx = CLEAN_ORDER.indexOf(b.cleanliness as typeof CLEAN_ORDER[number])
    if (aIdx !== -1 && bIdx !== -1 && Math.abs(aIdx - bIdx) <= 1) earned += 1
  }

  // Cooking
  if (a.cooks === b.cooks) earned += 1

  // Quiet preference
  if (a.prefers_quiet === b.prefers_quiet) earned += 1

  return Math.round((earned / MAX_POINTS) * 100)
}

// ── Match label ───────────────────────────────────────────────

export function getMatchLabel(score: number): MatchLabel {
  if (score >= 75) return 'great'
  if (score >= 50) return 'good'
  return 'decent'
}

// ── Why you match ─────────────────────────────────────────────
// Returns human-readable reasons for the match
// NN criteria first (higher weight), then preferences

export function getWhyMatch(a: UserProfile, b: UserProfile): string[] {
  const reasons: string[] = []

  // NN criteria
  if (a.diet === b.diet && a.diet !== 'none') {
    const dietLabels: Record<string, string> = {
      halal: 'Both halal',
      vegetarian: 'Both vegetarian',
      no_pork_beef: 'Both no pork/beef',
    }
    if (dietLabels[a.diet!]) reasons.push(dietLabels[a.diet!])
  }

  if (!a.smoking && !b.smoking) reasons.push('Both non-smokers')

  if (a.needs_ac && b.needs_ac) reasons.push('Both need AC')

  const hallA = a.hall_preference
  const hallB = b.hall_preference
  if (hallA && hallB && hallA === hallB && hallA !== 'Any hall is fine') {
    reasons.push(hallA)
  }

  // Preferences
  if (a.sleep_time != null && b.sleep_time != null) {
    const diff = Math.abs(a.sleep_time - b.sleep_time)
    if (diff <= 2 || diff >= 22) {
      if (a.sleep_time >= 23 || a.sleep_time <= 2) reasons.push('Night owls')
      else if (a.sleep_time <= 22 && a.sleep_time >= 20) reasons.push('Similar sleep schedule')
    }
  }

  if (a.social_style && a.social_style === b.social_style) {
    const labels: Record<string, string> = {
      introvert: 'Both introverts',
      ambivert: 'Both ambiverts',
      extrovert: 'Both extroverts',
    }
    if (labels[a.social_style]) reasons.push(labels[a.social_style])
  }

  if (a.cleanliness && a.cleanliness === b.cleanliness) {
    if (a.cleanliness === 'tidy') reasons.push('Super tidy')
  }

  if (a.study_location && a.study_location === b.study_location) {
    const labels: Record<string, string> = {
      library: 'Library studiers',
      room: 'Study at home',
      mixed: 'Flexible studiers',
      cafes: 'Cafe studiers',
    }
    if (labels[a.study_location]) reasons.push(labels[a.study_location])
  }

  if (a.prefers_quiet && b.prefers_quiet) reasons.push('Both prefer quiet')

  // Return top 5 only
  return reasons.slice(0, 5)
}
