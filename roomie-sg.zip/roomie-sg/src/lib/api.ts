// ─────────────────────────────────────────────────────────────
// roomie.sg — API helpers
// All Supabase calls live here.
// Person A imports from this file — never calls Supabase directly.
// ─────────────────────────────────────────────────────────────

import { supabase } from './supabase'
import type { UserProfile, Activity, UserFilters } from '../types'

// ── AUTH ──────────────────────────────────────────────────────

export async function signUpWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signUp({ email, password })
  if (error) throw error
  return data
}

export async function signInWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw error
  return data
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser()
  return user
}

// ── PROFILE ───────────────────────────────────────────────────

export async function getMyProfile(): Promise<UserProfile | null> {
  const user = await getCurrentUser()
  if (!user) return null

  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  if (error) throw error
  return data
}

export async function getProfileById(id: string): Promise<UserProfile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', id)
    .single()

  if (error) throw error
  return data
}

export async function updateMyProfile(updates: Partial<UserProfile>): Promise<UserProfile> {
  const user = await getCurrentUser()
  if (!user) throw new Error('Not authenticated')

  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', user.id)
    .select()
    .single()

  if (error) throw error
  return data
}

export async function uploadProfilePhoto(file: File): Promise<string> {
  const user = await getCurrentUser()
  if (!user) throw new Error('Not authenticated')

  const ext = file.name.split('.').pop()
  const path = `${user.id}/avatar.${ext}`

  const { error: uploadError } = await supabase.storage
    .from('profile-photos')
    .upload(path, file, { upsert: true })

  if (uploadError) throw uploadError

  const { data } = supabase.storage
    .from('profile-photos')
    .getPublicUrl(path)

  return data.publicUrl
}

// ── FEEDS ─────────────────────────────────────────────────────

// For You feed — algorithm ranked, hard filters applied
export async function getForYouFeed(filters: Partial<UserFilters> = {}) {
  const { data, error } = await supabase.rpc('get_for_you_feed', {
    p_user_id: (await getCurrentUser())?.id,
    p_require_halal: filters.require_halal ?? false,
    p_require_non_smoker: filters.require_non_smoker ?? false,
    p_require_ac: filters.require_ac ?? false,
    p_gender_pref: filters.gender_preference ?? 'any',
    p_limit: 50,
  })

  if (error) throw error

  // Fetch full profiles for the returned IDs
  const ids: string[] = data.map((r: { profile_id: string }) => r.profile_id)
  const scoreMap = new Map(data.map((r: { profile_id: string; score: number; is_mutual: boolean }) =>
    [r.profile_id, { score: r.score, is_mutual: r.is_mutual }]
  ))

  const { data: profiles, error: profilesError } = await supabase
    .from('profiles')
    .select('*')
    .in('id', ids)

  if (profilesError) throw profilesError
  return profiles.map((p: UserProfile) => ({
    ...p,
    score: scoreMap.get(p.id)?.score ?? 0,
    is_mutual_match: scoreMap.get(p.id)?.is_mutual ?? false,
  }))
}

// All NUS/NTU feed — everyone at same university, sorted by score
export async function getAllFeed() {
  const me = await getMyProfile()
  if (!me) throw new Error('Not authenticated')

  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('university', me.university)
    .eq('is_paused', false)
    .eq('is_verified', true)
    .neq('id', me.id)

  if (error) throw error
  return data as UserProfile[]
}

// Matches feed — only mutual likes
export async function getMatchesFeed() {
  const user = await getCurrentUser()
  if (!user) throw new Error('Not authenticated')

  // Get all people the user liked
  const { data: iLiked } = await supabase
    .from('likes')
    .select('liked_id')
    .eq('liker_id', user.id)

  const iLikedIds = (iLiked ?? []).map((l: { liked_id: string }) => l.liked_id)

  // Get all people who liked the user back (mutual)
  const { data: theyLikedMe } = await supabase
    .from('likes')
    .select('liker_id')
    .eq('liked_id', user.id)
    .in('liker_id', iLikedIds)

  const mutualIds = (theyLikedMe ?? []).map((l: { liker_id: string }) => l.liker_id)
  if (mutualIds.length === 0) return []

  const { data: profiles, error } = await supabase
    .from('profiles')
    .select('*')
    .in('id', mutualIds)

  if (error) throw error
  return profiles as UserProfile[]
}

// ── LIKES ─────────────────────────────────────────────────────

export async function sendLike(likedId: string): Promise<{ is_mutual_match: boolean }> {
  const user = await getCurrentUser()
  if (!user) throw new Error('Not authenticated')

  const { data, error } = await supabase.rpc('send_like', {
    p_liker_id: user.id,
    p_liked_id: likedId,
  })

  if (error) throw error
  return data
}

export async function removeLike(likedId: string) {
  const user = await getCurrentUser()
  if (!user) throw new Error('Not authenticated')

  const { error } = await supabase
    .from('likes')
    .delete()
    .eq('liker_id', user.id)
    .eq('liked_id', likedId)

  if (error) throw error
}

export async function checkIfILiked(profileId: string): Promise<boolean> {
  const user = await getCurrentUser()
  if (!user) return false

  const { data } = await supabase
    .from('likes')
    .select('id')
    .eq('liker_id', user.id)
    .eq('liked_id', profileId)
    .single()

  return !!data
}

// ── ACTIVITY ──────────────────────────────────────────────────

export async function getActivity(): Promise<Activity[]> {
  const user = await getCurrentUser()
  if (!user) throw new Error('Not authenticated')

  const { data, error } = await supabase
    .from('activity')
    .select(`
      *,
      actor:actor_id (
        id, name, photo_url, hall_preference, connect_platform, connect_handle
      )
    `)
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(50)

  if (error) throw error
  return data as Activity[]
}

export async function getUnreadCount(): Promise<number> {
  const user = await getCurrentUser()
  if (!user) return 0

  const { count } = await supabase
    .from('activity')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', user.id)
    .eq('is_read', false)

  return count ?? 0
}

export async function markActivityRead() {
  const user = await getCurrentUser()
  if (!user) return

  await supabase.rpc('mark_activity_read', { p_user_id: user.id })
}

// ── CONNECT ───────────────────────────────────────────────────

export async function logConnect(connectedToId: string) {
  const user = await getCurrentUser()
  if (!user) throw new Error('Not authenticated')

  await supabase.rpc('log_connect', {
    p_connector_id: user.id,
    p_connected_to_id: connectedToId,
  })
}

// Build the Telegram or WhatsApp deep link for a profile
export function buildConnectLink(profile: UserProfile): string | null {
  if (!profile.connect_handle) return null
  if (profile.connect_platform === 'telegram') {
    const handle = profile.connect_handle.replace('@', '')
    return `https://t.me/${handle}`
  }
  if (profile.connect_platform === 'whatsapp') {
    const number = profile.connect_handle.replace(/\D/g, '')
    return `https://wa.me/${number}`
  }
  return null
}

// Build the pre-written intro message
export function buildIntroMessage(myProfile: UserProfile, theirProfile: UserProfile, whyMatch: string[]): string {
  const reasons = whyMatch.slice(0, 2).join(', ')
  return `Hey! I'm ${myProfile.name} from roomie.sg. We matched — ${reasons}. Would love to chat about rooming together!`
}
