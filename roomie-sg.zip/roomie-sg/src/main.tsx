import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'

// Placeholder App — Person A will build out the full routing
function App() {
  return (
    <div style={{ fontFamily: 'Syne, sans-serif', textAlign: 'center', padding: '4rem 2rem', background: '#FAF7F2', minHeight: '100vh' }}>
      <h1 style={{ fontSize: '2.5rem', color: '#C4581A', fontWeight: 800 }}>
        roomie<span style={{ color: '#5C7A62' }}>.sg</span>
      </h1>
      <p style={{ color: '#A07850', marginTop: '0.5rem' }}>find your perfect uni roommate</p>
      <p style={{ color: '#C4A882', marginTop: '2rem', fontSize: '0.9rem' }}>
        Setting up... check back soon.
      </p>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
