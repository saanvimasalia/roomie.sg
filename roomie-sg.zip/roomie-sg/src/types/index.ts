// ─────────────────────────────────────────────
// roomie.sg — Shared TypeScript Types
// Person B owns this file. Person A reads it.
// Both agree on this before writing any code.
// ─────────────────────────────────────────────

export type University = 'NUS' | 'NTU'

export type Diet = 'halal' | 'vegetarian' | 'no_pork_beef' | 'none'

export type SocialStyle = 'introvert' | 'ambivert' | 'extrovert'

export type GuestFrequency = 'never' | 'rarely' | 'sometimes' | 'often'

export type Cleanliness = 'tidy' | 'average' | 'relaxed'

export type StudyLocation = 'room' | 'library' | 'mixed' | 'cafes'

export type ConnectPlatform = 'telegram' | 'whatsapp'

export type MatchLabel = 'great' | 'good' | 'decent'

export type Semester = 'Sem1' | 'Sem2'

export type Year = 'Y1' | 'Y2' | 'Y3' | 'Y4' | 'Grad'

export type ActivityType = 'new_like' | 'new_match' | 'connected'

// ─────────────────────────────────────────────
// Core user profile — matches database shape
// ─────────────────────────────────────────────
export interface UserProfile {
  // Identity
  id: string
  email: string
  university: University
  created_at: string

  // Basic info
  name: string
  age: number | null
  year: Year | null
  faculty: string | null
  nationality: string | null
  photo_url: string | null

  // Accommodation
  hall_preference: string | null
  move_in_semester: Semester | null

  // Lifestyle — self description
  diet: Diet | null
  wake_time: number | null      // Hour 0-23
  sleep_time: number | null     // Hour 0-23
  study_location: StudyLocation | null
  social_style: SocialStyle | null
  guest_frequency: GuestFrequency | null
  cleanliness: Cleanliness | null
  smoking: boolean
  needs_ac: boolean
  cooks: boolean
  prefers_quiet: boolean
  has_pet: boolean

  // Allergies
  allergies: string[]
  allergies_other: string | null

  // Prompts
  prompt_1_answer: string | null
  prompt_2_question: string | null
  prompt_2_answer: string | null

  // Connect
  connect_platform: ConnectPlatform | null
  connect_handle: string | null

  // App state
  is_paused: boolean
  is_verified: boolean
}

// ─────────────────────────────────────────────
// Profile with computed match data
// Returned by the feed queries
// ─────────────────────────────────────────────
export interface ProfileWithScore extends UserProfile {
  score: number                 // 0-100
  label: MatchLabel
  why_match: string[]           // e.g. ["Both halal", "Night owls", "Eusoff Hall"]
  is_mutual_match: boolean      // true if both have liked each other
  i_liked_them: boolean         // true if current user has liked this profile
}

// ─────────────────────────────────────────────
// Like record
// ─────────────────────────────────────────────
export interface Like {
  id: string
  liker_id: string
  liked_id: string
  created_at: string
}

// ─────────────────────────────────────────────
// Activity / notification record
// ─────────────────────────────────────────────
export interface Activity {
  id: string
  user_id: string
  type: ActivityType
  actor_id: string
  is_read: boolean
  created_at: string
  // Joined actor profile for display
  actor?: Pick<UserProfile, 'id' | 'name' | 'photo_url' | 'hall_preference' | 'connect_platform' | 'connect_handle'>
}

// ─────────────────────────────────────────────
// Filter preferences (set by user after signup)
// Stored in localStorage or a separate user_filters table
// ─────────────────────────────────────────────
export interface UserFilters {
  // Non-negotiables (hard filters)
  require_halal: boolean
  require_non_smoker: boolean
  require_ac: boolean
  gender_preference: 'female' | 'male' | 'any'

  // Preferences (affect ranking, not hard filter)
  prefer_tidy: boolean
  prefer_night_owl: boolean
  prefer_early_bird: boolean
  prefer_quiet_studier: boolean
  prefer_introvert: boolean
  prefer_rarely_guests: boolean
}

// ─────────────────────────────────────────────
// Onboarding form state (used by Person A)
// Mirrors UserProfile but all nullable for incremental fill
// ─────────────────────────────────────────────
export type OnboardingData = Partial<Omit<UserProfile, 'id' | 'created_at' | 'is_verified'>>

// ─────────────────────────────────────────────
// Prompt options (Person A renders these, Person B doesn't need to store the keys)
// ─────────────────────────────────────────────
export const PROMPT_2_OPTIONS = [
  { key: 'home_because', label: "You'll know I'm home because..." },
  { key: 'shared_space', label: "The one thing I need in a shared space is..." },
  { key: 'flatmate_who', label: "I'm the kind of flatmate who..." },
  { key: 'tuesday_night', label: "On a random Tuesday night I'm usually..." },
  { key: 'grocery', label: "Grocery runs and cooking are..." },
  { key: 'sleep_schedule', label: "My sleep schedule is basically..." },
] as const

export type Prompt2Key = typeof PROMPT_2_OPTIONS[number]['key']
