# Supabase Setup — Person B

Complete guide to setting up the roomie.sg backend from scratch.

---

## Step 1: Create a Supabase project

1. Go to https://supabase.com and sign in
2. Click "New project"
3. Name it `roomie-sg`
4. Choose a strong database password (save it)
5. Select region: **Southeast Asia (Singapore)** — closest to your users
6. Click "Create new project" and wait ~2 minutes

---

## Step 2: Get your API keys

1. In your project, go to **Settings → API**
2. Copy:
   - **Project URL** → `VITE_SUPABASE_URL`
   - **anon public key** → `VITE_SUPABASE_ANON_KEY`
3. Share these with Person A (they go in `.env.local`)
4. **Never share the `service_role` key** — it bypasses all RLS

---

## Step 3: Run migrations in order

Go to **SQL Editor** in your Supabase dashboard.
Run each file in order, one at a time.

```
1. supabase/migrations/001_profiles.sql
2. supabase/migrations/002_likes.sql
3. supabase/migrations/003_activity.sql
4. supabase/migrations/004_functions.sql
5. supabase/migrations/005_rls.sql
```

Paste the contents of each file into the SQL editor and click **Run**.

---

## Step 4: Set up Storage for profile photos

1. Go to **Storage** in your Supabase dashboard
2. Click "New bucket"
3. Name: `profile-photos`
4. Toggle **Public bucket** ON (so photos can be displayed without auth)
5. Click "Create bucket"
6. Go to **Policies** tab inside the bucket
7. Uncomment and run the storage policy SQL at the bottom of `005_rls.sql`

---

## Step 5: Configure email auth

1. Go to **Authentication → Settings**
2. Under **Email Auth**, make sure **"Enable email confirmations"** is ON
3. Set **"Confirm email"** redirect URL to: `http://localhost:5173/auth/callback`
   (Update to your Vercel URL when deployed)
4. Optional: Set up a custom SMTP server for branded emails
   - Go to **Settings → Auth → SMTP Settings**
   - Use Gmail, Resend, or SendGrid (all have free tiers)

---

## Step 6: Verify everything works

Run this test query in the SQL Editor:

```sql
-- Check tables exist
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;

-- Should return: activity, likes, profiles
```

```sql
-- Check functions exist
SELECT routine_name FROM information_schema.routines
WHERE routine_schema = 'public'
ORDER BY routine_name;

-- Should include: calc_match_score, get_for_you_feed,
-- handle_new_user, is_mutual_match, log_connect,
-- mark_activity_read, send_like
```

---

## Step 7: Seed test data (optional, for development)

```sql
-- Insert a test NUS profile
-- (Only works after creating a real auth user via the signup flow)
-- Use the app to sign up with a test email first, then update the profile:

UPDATE public.profiles
SET
  name = 'Test User',
  age = 20,
  year = 'Y2',
  faculty = 'Computer Science',
  nationality = 'Singaporean',
  hall_preference = 'Eusoff Hall',
  move_in_semester = 'Sem1',
  diet = 'halal',
  wake_time = 9,
  sleep_time = 1,
  study_location = 'library',
  social_style = 'introvert',
  guest_frequency = 'rarely',
  cleanliness = 'tidy',
  smoking = false,
  needs_ac = true,
  cooks = true,
  prefers_quiet = true,
  has_pet = false,
  allergies = ARRAY['nuts'],
  prompt_1_answer = 'library after 10pm where silence is sacred',
  prompt_2_question = 'home_because',
  prompt_2_answer = 'the kettle is always on and K-drama is playing quietly',
  connect_platform = 'telegram',
  connect_handle = '@testuser',
  is_verified = true
WHERE email = 'your-test-email@e.nus.edu.sg';
```

---

## Useful SQL queries for debugging

```sql
-- See all profiles
SELECT id, name, university, is_paused, is_verified FROM public.profiles;

-- See all likes
SELECT * FROM public.likes;

-- Check if two users are a mutual match
SELECT public.is_mutual_match('user-a-uuid', 'user-b-uuid');

-- Get activity for a user
SELECT * FROM public.activity WHERE user_id = 'user-uuid' ORDER BY created_at DESC;

-- Test the matching score between two users
SELECT public.calc_match_score('user-a-uuid', 'user-b-uuid');
```

---

## Deploying to production

1. Deploy frontend to Vercel (Person A handles this)
2. In Supabase → Authentication → Settings, add your production URL to:
   - **Site URL**: `https://roomie.sg`
   - **Redirect URLs**: `https://roomie.sg/auth/callback`
3. Update environment variables in Vercel dashboard with the same Supabase keys
